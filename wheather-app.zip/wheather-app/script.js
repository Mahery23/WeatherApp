// Clé API pour accéder à OpenWeatherMap
const apiKey = 'f7b44a6c8b6696a969bbc8340ff84aca';

let map; // Variable pour stocker l'objet de la carte

// Événement lié au bouton "getWeather" pour récupérer les données météo
document.getElementById('getWeather').addEventListener('click', async () => {
  const city = document.getElementById('city').value.trim(); // Récupère la ville entrée
  const errorMessage = document.getElementById('errorMessage'); // Élément pour afficher les erreurs
  errorMessage.style.display = 'none';

  // Vérifie si une ville a été entrée
  if (!city) {
    showError('Veuillez entrer une ville.'); // Affiche un message d'erreur si aucune ville n'est entrée
    return;
  }

  // Masque les sections de résultats précédentes
  document.getElementById('currentWeather').style.display = 'none';
  document.getElementById('mapSection').style.display = 'none';
  document.getElementById('forecast').style.display = 'none';
  document.getElementById('forecastContainer').innerHTML = '';

  const spinner = document.getElementById('spinner');
  spinner.style.display = 'block';

  try {
    // Récupère les données météo actuelles de l'API
    const currentResponse = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&lang=fr&appid=${apiKey}`);
    const currentData = await currentResponse.json();

    // Vérifie si la ville existe dans la base de données
    if (currentData.cod !== 200) {
      showError('Ville non trouvée.');
      return;
    }

    // Récupère les informations météo et les affiche sur l'interface
    const { name, country, weather, main, wind } = currentData;
    document.getElementById('currentCity').textContent = `${name}`;
    document.getElementById('currentDescription').textContent = weather[0].description;
    document.getElementById('currentIcon').src = `https://openweathermap.org/img/wn/${weather[0].icon}@2x.png`;
    document.getElementById('currentTemp').textContent = main.temp;
    document.getElementById('currentHumidity').textContent = main.humidity;
    document.getElementById('currentFeelsLike').textContent = main.feels_like;
    document.getElementById('currentWindSpeed').textContent = wind.speed;

    // Affiche la section des données météo actuelles
    document.getElementById('currentWeather').style.display = 'block';

    // Met à jour la carte avec la position actuelle de la ville
    if (map) map.remove();
    document.getElementById('mapSection').style.display = 'block';
    map = L.map('map').setView([currentData.coord.lat, currentData.coord.lon], 10);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map); // Ajoute la couche de tuiles OpenStreetMap
    L.marker([currentData.coord.lat, currentData.coord.lon]).addTo(map).bindPopup(`${name}`).openPopup(); // Place un marqueur sur la carte

    // Récupère les prévisions météo
    const forecastResponse = await fetch(`https://api.openweathermap.org/data/2.5/forecast?q=${city}&units=metric&lang=fr&appid=${apiKey}`);
    const forecastData = await forecastResponse.json();

    // Vérifie si les prévisions ont été récupérées avec succès
    if (forecastData.cod !== "200") {
      throw new Error('Erreur dans la récupération des prévisions météo.');
    }

    // Prépare et affiche les prévisions météo
    const forecastContainer = document.getElementById('forecastContainer');
    const currentDate = new Date().toISOString().split('T')[0];

    // Regroupe les prévisions par date
    const groupedForecasts = {};
    forecastData.list.forEach((item) => {
      const date = item.dt_txt.split(' ')[0];
      if (date !== currentDate) {
        if (!groupedForecasts[date]) groupedForecasts[date] = [];
        groupedForecasts[date].push(item);
      }
    });

    // Crée un élément pour chaque prévision regroupée par date
    Object.keys(groupedForecasts).forEach((date) => {
      const tempMin = Math.min(...groupedForecasts[date].map(f => f.main.temp_min)); // Température minimale
      const tempMax = Math.max(...groupedForecasts[date].map(f => f.main.temp_max)); // Température maximale
      const { weather } = groupedForecasts[date][0]; // Récupère l'icon et la description météo

      // Formate la date pour affichage
      const formattedDate = new Date(date).toLocaleDateString('fr-FR', {
        weekday: 'long',
        day: 'numeric',
        month: 'short',
        year: 'numeric'
      });

      // Crée un élément HTML pour afficher la prévision
      const element = document.createElement('div');
      element.classList.add('forecast-item');
      element.innerHTML = `
        <h3>${formattedDate}</h3>
        <img src="https://openweathermap.org/img/wn/${weather[0].icon}@2x.png" alt="${weather[0].description}" />
        <p>${weather[0].description}</p>
        <p><strong>Min :</strong> ${tempMin}°C</p>
        <p><strong>Max :</strong> ${tempMax}°C</p>
      `;
      forecastContainer.appendChild(element); // Ajoute l'élément de prévision à la page
    });

    // Affiche la section des prévisions
    document.getElementById('forecast').style.display = 'block';
  } catch (error) {
    showError('Une erreur est survenue : ' + error.message); // Affiche un message d'erreur si une exception est levée
  } finally {
    spinner.style.display = 'none'; // Masque le spinner après l'exécution
  }
});

// Fonction pour afficher un message d'erreur
function showError(message) {
  const errorMessage = document.getElementById('errorMessage');
  errorMessage.textContent = message;
  errorMessage.style.display = 'block';
}
